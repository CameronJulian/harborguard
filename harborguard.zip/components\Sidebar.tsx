"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { CSSProperties } from "react";

type UserRole = "admin" | "manager" | "viewer";

type Props = {
  email?: string | null;
  role?: UserRole | null;
  onSignOut: () => void;
  isMobile?: boolean;
  onNavigate?: () => void;
};

const cardStyle: CSSProperties = {
  background: "#ffffff",
  borderRadius: 20,
  boxShadow: "0 12px 32px rgba(15, 23, 42, 0.08)",
  border: "1px solid #e5e7eb",
};

const mutedTextStyle: CSSProperties = {
  color: "#64748b",
  margin: 0,
};

export default function Sidebar({
  email,
  role,
  onSignOut,
  isMobile,
  onNavigate,
}: Props) {
  const pathname = usePathname();

  const canManageReports = role === "admin";

  function navStyle(href: string): CSSProperties {
    const active = pathname === href;

    return {
      display: "block",
      width: "100%",
      textAlign: "left",
      padding: "14px 16px",
      borderRadius: 14,
      border: active ? "1px solid #bfdbfe" : "1px solid transparent",
      background: active ? "#dbeafe" : "transparent",
      color: active ? "#1d4ed8" : "#111827",
      fontWeight: active ? 800 : 600,
      textDecoration: "none",
      fontSize: 15,
    };
  }

  return (
    <aside
      style={{
        ...cardStyle,
        padding: 24,
        alignSelf: "start",
        position: isMobile ? "static" : "sticky",
        top: 20,
      }}
    >
      {!isMobile && (
        <div style={{ marginBottom: 28 }}>
          <h1 style={{ fontSize: 36, lineHeight: 1.05, margin: "0 0 8px 0" }}>
            HarborGuard
          </h1>
          <p style={{ ...mutedTextStyle, fontSize: 16 }}>
            Fish Supply Chain Monitoring System
          </p>
        </div>
      )}

      <div style={{ display: "grid", gap: 10, marginBottom: 28 }}>
        <Link href="/dashboard" style={navStyle("/dashboard")} onClick={onNavigate}>
          Dashboard
        </Link>

        <Link href="/billing" style={navStyle("/billing")} onClick={onNavigate}>
          Billing
        </Link>

        <Link href="/analytics" style={navStyle("/analytics")} onClick={onNavigate}>
          Analytics
        </Link>

        <Link href="/fleet" style={navStyle("/fleet")} onClick={onNavigate}>
          Fleet Dashboard
        </Link>

        <Link href="/driver" style={navStyle("/driver")} onClick={onNavigate}>
          Driver Emergency
        </Link>

        <Link href="/route-replay" style={navStyle("/route-replay")} onClick={onNavigate}>
          Route Replay
        </Link>

        <Link href="/geofences" style={navStyle("/geofences")} onClick={onNavigate}>
          Geofence Management
        </Link>

        <Link href="/fleet/vehicles" style={navStyle("/fleet/vehicles")} onClick={onNavigate}>
          Vehicles
        </Link>

        <Link href="/trips" style={navStyle("/trips")} onClick={onNavigate}>
          Trips
        </Link>

        <Link href="/vehicle-alerts" style={navStyle("/vehicle-alerts")} onClick={onNavigate}>
          Vehicle Alerts
        </Link>

        <Link href="/risk-dashboard" style={navStyle("/risk-dashboard")} onClick={onNavigate}>
          Risk Dashboard
        </Link>

        <Link href="/command-center" style={navStyle("/command-center")} onClick={onNavigate}>
          Command Center
        </Link>

        {canManageReports && (
          <>
            <Link href="/report-settings" style={navStyle("/report-settings")} onClick={onNavigate}>
              Report Settings
            </Link>

            <Link href="/report-history" style={navStyle("/report-history")} onClick={onNavigate}>
              Reports History
            </Link>

            <Link href="/report-admin" style={navStyle("/report-admin")} onClick={onNavigate}>
              Report Admin
            </Link>
          </>
        )}

        <Link href="/batches" style={navStyle("/batches")} onClick={onNavigate}>
          Recent Batches
        </Link>

        <Link href="/incidents" style={navStyle("/incidents")} onClick={onNavigate}>
          Incident Management
        </Link>
      </div>

      <div style={{ borderTop: "1px solid #e5e7eb", paddingTop: 18 }}>
        <div style={{ fontSize: 13, color: "#6b7280", marginBottom: 8 }}>
          Signed in as
        </div>

        <div style={{ fontWeight: 700, wordBreak: "break-word", marginBottom: 6 }}>
          {email || "Unknown"}
        </div>

        <div
          style={{
            fontSize: 13,
            color: "#64748b",
            marginBottom: 12,
            textTransform: "capitalize",
          }}
        >
          Role: {role || "unknown"}
        </div>

        <button
          onClick={onSignOut}
          style={{
            padding: "12px 16px",
            borderRadius: 12,
            border: "1px solid #d1d5db",
            background: "#fff",
            color: "#111827",
            fontWeight: 700,
            cursor: "pointer",
          }}
        >
          Sign Out
        </button>
      </div>
    </aside>
  );
}



