import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { hasPermission } from "@/lib/rbac";
import { requireOrganization } from "@/lib/server-auth";
import { requirePremiumAccess } from "@/lib/require-premium";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

const RetryOneSchema = z.object({
  logId: z.string().uuid(),
});

type LogRow = {
  id: string;
  subscription_id: string | null;
  user_id: string | null;
  email: string;
  full_name: string | null;
  report_frequency: "daily" | "weekly";
  start_date: string;
  end_date: string;
  status: "success" | "failed";
  error_message: string | null;
  created_at: string | null;
  organization_id: string;
};

export async function POST(req: Request) {
  try {
    const { organizationId, role } = await requireOrganization();

    const premium = await requirePremiumAccess(organizationId);

    if (!premium.allowed) {
      return NextResponse.json(
        { error: "Professional subscription required." },
        { status: 403 }
      );
    }

    if (!hasPermission(role, "reports:manage")) {
      return NextResponse.json(
        { error: "You do not have permission to manage reports." },
        { status: 403 }
      );
    }

    const { logId } = RetryOneSchema.parse(await req.json());

    const { data: log, error } = await supabase
      .from("report_delivery_logs")
      .select(
        "id, subscription_id, user_id, email, full_name, report_frequency, start_date, end_date, status, error_message, created_at, organization_id"
      )
      .eq("id", logId)
      .eq("organization_id", organizationId)
      .maybeSingle();

    if (error) {
      return NextResponse.json(
        { error: error.message },
        { status: 500 }
      );
    }

    if (!log) {
      return NextResponse.json(
        { error: "Log not found." },
        { status: 404 }
      );
    }

    const row = log as LogRow;
    const origin = process.env.NEXT_PUBLIC_SITE_URL;
    const cronSecret = process.env.CRON_SECRET;

    if (!origin) {
      return NextResponse.json(
        { error: "NEXT_PUBLIC_SITE_URL is not configured." },
        { status: 500 }
      );
    }

    if (!cronSecret) {
      return NextResponse.json(
        { error: "CRON_SECRET is not configured." },
        { status: 500 }
      );
    }

    const response = await fetch(`${origin}/api/reports/send`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-cron-secret": cronSecret,
        "x-user-id": String(row.user_id || ""),
      },
      cache: "no-store",
      body: JSON.stringify({
        startDate: row.start_date,
        endDate: row.end_date,
        email: row.email,
      }),
    });

    const rawText = await response.text();

    let result: unknown;

    try {
      result = JSON.parse(rawText);
    } catch {
      result = {
        error: "Non-JSON response returned from /api/reports/send",
        details: rawText.slice(0, 300),
      };
    }

    const resultObject =
      result && typeof result === "object"
        ? (result as { success?: boolean; error?: string; details?: string })
        : {};

    if (!response.ok || !resultObject.success) {
      const errorMessage =
        resultObject.error ||
        resultObject.details ||
        "Failed to retry report.";

      await supabase.from("report_delivery_logs").insert({
        organization_id: organizationId,
        subscription_id: row.subscription_id,
        user_id: row.user_id,
        email: row.email,
        full_name: row.full_name,
        report_frequency: row.report_frequency,
        start_date: row.start_date,
        end_date: row.end_date,
        status: "failed",
        error_message: errorMessage,
      });

      return NextResponse.json({
        success: false,
        error: errorMessage,
      });
    }

    await supabase.from("report_delivery_logs").insert({
      organization_id: organizationId,
      subscription_id: row.subscription_id,
      user_id: row.user_id,
      email: row.email,
      full_name: row.full_name,
      report_frequency: row.report_frequency,
      start_date: row.start_date,
      end_date: row.end_date,
      status: "success",
      error_message: null,
    });

    return NextResponse.json({
      success: true,
      message: "Report retried successfully.",
    });
  } catch (err: unknown) {
    const message =
      err instanceof Error ? err.message : "Retry failed.";

    const status =
      message === "Unauthorized"
        ? 401
        : message === "Permission denied"
        ? 403
        : 500;

    return NextResponse.json(
      { error: message },
      { status }
    );
  }
}
