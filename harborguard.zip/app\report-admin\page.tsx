﻿"use client";

import { CSSProperties, useEffect, useMemo, useState } from "react";
import TrialBanner from "@/components/billing/TrialBanner";
import { usePremiumAccess } from "@/hooks/usePremiumAccess";
import PremiumGate from "@/components/PremiumGate";

import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from "recharts";
import AppShell from "@/components/AppShell";
import RoleGuard from "@/components/RoleGuard";
import { supabase } from "@/lib/supabase";

type ReportDeliveryLogRow = {
  id: string;
  subscription_id: string | null;
  user_id: string | null;
  email: string;
  full_name: string | null;
  report_frequency: "daily" | "weekly";
  start_date: string;
  end_date: string;
  status: "success" | "failed";
  error_message: string | null;
  created_at: string | null;
};

type ReportSubscriptionRow = {
  id: string;
  user_id: string | null;
  email: string;
  full_name: string | null;
  is_enabled: boolean;
  report_frequency: "daily" | "weekly";
  created_at: string | null;
};

const cardStyle: CSSProperties = {
  background: "#ffffff",
  borderRadius: 20,
  boxShadow: "0 12px 32px rgba(15, 23, 42, 0.08)",
  border: "1px solid #e5e7eb",
};

const buttonStyle: CSSProperties = {
  padding: "12px 16px",
  borderRadius: 12,
  border: "none",
  background: "linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)",
  color: "#fff",
  fontWeight: 700,
  cursor: "pointer",
};

const secondaryButtonStyle: CSSProperties = {
  padding: "12px 16px",
  borderRadius: 12,
  border: "1px solid #d1d5db",
  background: "#fff",
  color: "#111827",
  fontWeight: 700,
  cursor: "pointer",
};

const dangerButtonStyle: CSSProperties = {
  padding: "12px 16px",
  borderRadius: 12,
  border: "1px solid #fecaca",
  background: "#fff",
  color: "#b91c1c",
  fontWeight: 700,
  cursor: "pointer",
};

const sectionTitleStyle: CSSProperties = {
  fontSize: 28,
  fontWeight: 800,
  margin: "0 0 8px 0",
};

const mutedTextStyle: CSSProperties = {
  color: "#64748b",
  margin: 0,
};


function formatDateTime(value: string | null) {
  if (!value) return "-";
  return new Date(value).toLocaleString();
}

function formatShortDate(value: string | null) {
  if (!value) return "-";
  const date = new Date(value);
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export default function ReportAdminPage() {
  const [logs, setLogs] = useState<ReportDeliveryLogRow[]>([]);
  const [subscriptions, setSubscriptions] = useState<ReportSubscriptionRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingSubscriptions, setLoadingSubscriptions] = useState(false);
  const [message, setMessage] = useState("");
  const [runningDaily, setRunningDaily] = useState(false);
  const {
  premiumAllowed,
  subscriptionLoaded,
  subscription,
} = usePremiumAccess();
  const [runningWeekly, setRunningWeekly] = useState(false);
  const [retryingFailed, setRetryingFailed] = useState(false);
  const [cleaningFailed, setCleaningFailed] = useState(false);
  const [togglingSubscriptionId, setTogglingSubscriptionId] = useState<string | null>(null);

  async function loadLogs() {
    setLoading(true);

    const { data, error } = await supabase
      .from("report_delivery_logs")
      .select(
        "id, subscription_id, user_id, email, full_name, report_frequency, start_date, end_date, status, error_message, created_at"
      )
      .order("created_at", { ascending: false })
      .limit(200);

    if (error) {
      setMessage(`Failed to load admin data: ${error.message}`);
      setLoading(false);
      return;
    }

    setLogs((data as ReportDeliveryLogRow[]) || []);
    setLoading(false);
  }

  async function loadSubscriptions() {
    setLoadingSubscriptions(true);

    const { data, error } = await supabase
      .from("report_subscriptions")
      .select("id, user_id, email, full_name, is_enabled, report_frequency, created_at")
      .order("created_at", { ascending: false });

    if (error) {
      setMessage(`Failed to load subscriptions: ${error.message}`);
      setLoadingSubscriptions(false);
      return;
    }

    setSubscriptions((data as ReportSubscriptionRow[]) || []);
    setLoadingSubscriptions(false);
  }

  useEffect(() => {
	 
    loadLogs();
    loadSubscriptions();

    const logsChannel = supabase
      .channel("report-admin-live")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "report_delivery_logs" },
        () => loadLogs()
      )
      .subscribe();

    const subscriptionsChannel = supabase
      .channel("report-subscriptions-admin-live")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "report_subscriptions" },
        () => loadSubscriptions()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(logsChannel);
      supabase.removeChannel(subscriptionsChannel);
    };
  }, []);

  async function runReports(period: "daily" | "weekly") {
    setMessage("");

    if (period === "daily") setRunningDaily(true);
    if (period === "weekly") setRunningWeekly(true);

    try {
      const response = await fetch("/api/reports/run", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ period }),
      });

      const result = await response.json();

      if (!response.ok) {
        setMessage(result.error || `Failed to run ${period} reports.`);
        return;
      }

      setMessage(
        `${period} reports completed. Sent: ${result.successCount}, Failed: ${result.failedCount}`
      );
      await loadLogs();
    } catch (err: any) {
      setMessage(err.message || `Failed to run ${period} reports.`);
    } finally {
      if (period === "daily") setRunningDaily(false);
      if (period === "weekly") setRunningWeekly(false);
    }
  }

  async function retryFailedReports() {
    setRetryingFailed(true);
    setMessage("");

    try {
      const response = await fetch("/api/reports/retry", {
        method: "POST",
      });

      const result = await response.json();

      if (!response.ok) {
        setMessage(result.error || "Failed to retry failed reports.");
        return;
      }

      setMessage(
        `Retry completed. Retried ${result.retried || 0} failed report(s). Success: ${result.successCount || 0}, Failed: ${result.failedCount || 0}`
      );
      await loadLogs();
    } catch (err: any) {
      setMessage(err.message || "Failed to retry failed reports.");
    } finally {
      setRetryingFailed(false);
    }
  }

  async function clearOldFailedLogs() {
    const confirmed = window.confirm(
      "Delete failed logs older than 1 day? This only removes historical failed records."
    );

    if (!confirmed) return;

    setCleaningFailed(true);
    setMessage("");

    try {
      const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

      const { error } = await supabase
        .from("report_delivery_logs")
        .delete()
        .eq("status", "failed")
        .lt("created_at", cutoff);

      if (error) {
        setMessage(`Failed to clean old failed logs: ${error.message}`);
        return;
      }

      setMessage("Old failed logs removed successfully.");
      await loadLogs();
    } catch (err: any) {
      setMessage(err.message || "Failed to clean old failed logs.");
    } finally {
      setCleaningFailed(false);
    }
  }

  async function toggleSubscription(subscription: ReportSubscriptionRow) {
    setTogglingSubscriptionId(subscription.id);
    setMessage("");

    try {
      const response = await fetch("/api/reports/toggle-subscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          subscriptionId: subscription.id,
          isEnabled: subscription.is_enabled,
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        setMessage(result.error || "Failed to toggle subscription.");
        return;
      }

      setMessage(
        `${subscription.email} is now ${result.newState ? "enabled" : "disabled"} for ${subscription.report_frequency} reports.`
      );
      await loadSubscriptions();
    } catch (err: any) {
      setMessage(err.message || "Failed to toggle subscription.");
    } finally {
      setTogglingSubscriptionId(null);
    }
  }

  const summary = useMemo(() => {
    const total = logs.length;
    const success = logs.filter((l) => l.status === "success").length;
    const failed = logs.filter((l) => l.status === "failed").length;

    const last24hCutoff = Date.now() - 24 * 60 * 60 * 1000;
    const last24hLogs = logs.filter((l) => {
      if (!l.created_at) return false;
      return new Date(l.created_at).getTime() >= last24hCutoff;
    });

    const last24hSuccess = last24hLogs.filter((l) => l.status === "success").length;
    const last24hFailed = last24hLogs.filter((l) => l.status === "failed").length;
    const successRate = total > 0 ? ((success / total) * 100).toFixed(1) : "0.0";

    const lastRunAt = logs.length > 0 ? logs[0].created_at : null;

    return {
      total,
      success,
      failed,
      last24hLogs: last24hLogs.length,
      last24hSuccess,
      last24hFailed,
      successRate,
      lastRunAt,
    };
  }, [logs]);

  const failedRecipients = useMemo(() => {
    const map = new Map<string, number>();

    for (const log of logs) {
      if (log.status !== "failed") continue;
      map.set(log.email, (map.get(log.email) || 0) + 1);
    }

    return [...map.entries()]
      .map(([email, count]) => ({ email, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, [logs]);

  const recentFailures = useMemo(
    () => logs.filter((l) => l.status === "failed").slice(0, 10),
    [logs]
  );

  const recentSuccesses = useMemo(
    () => logs.filter((l) => l.status === "success").slice(0, 10),
    [logs]
  );

  const statusChartData = useMemo(
    () => [
      { name: "Success", value: summary.success },
      { name: "Failed", value: summary.failed },
    ],
    [summary.success, summary.failed]
  );

  const last7DaysTrend = useMemo(() => {
    const days: Array<{
      key: string;
      label: string;
      success: number;
      failed: number;
      total: number;
    }> = [];

    for (let i = 6; i >= 0; i--) {
      const day = new Date();
      day.setHours(0, 0, 0, 0);
      day.setDate(day.getDate() - i);

      const nextDay = new Date(day);
      nextDay.setDate(nextDay.getDate() + 1);

      const key = day.toISOString().slice(0, 10);
      const label = key.slice(5);
      const matching = logs.filter((log) => {
        if (!log.created_at) return false;
        const created = new Date(log.created_at).getTime();
        return created >= day.getTime() && created < nextDay.getTime();
      });

      const success = matching.filter((log) => log.status === "success").length;
      const failed = matching.filter((log) => log.status === "failed").length;

      days.push({
        key,
        label,
        success,
        failed,
        total: matching.length,
      });
    }

    return days;
  }, [logs]);

  const frequencyChartData = useMemo(
    () => [
      {
        name: "Daily",
        enabled: subscriptions.filter(
          (sub) => sub.report_frequency === "daily" && sub.is_enabled
        ).length,
        disabled: subscriptions.filter(
          (sub) => sub.report_frequency === "daily" && !sub.is_enabled
        ).length,
      },
      {
        name: "Weekly",
        enabled: subscriptions.filter(
          (sub) => sub.report_frequency === "weekly" && sub.is_enabled
        ).length,
        disabled: subscriptions.filter(
          (sub) => sub.report_frequency === "weekly" && !sub.is_enabled
        ).length,
      },
    ],
    [subscriptions]
  );

  const failedRecipientsChartData = useMemo(
    () => failedRecipients.slice(0, 6).map((item) => ({
      email: item.email.length > 18 ? `${item.email.slice(0, 18)}...` : item.email,
      count: item.count,
    })),
    [failedRecipients]
  );

  if (
  subscriptionLoaded &&
  !premiumAllowed
) {
  return (
    <AppShell>
	<TrialBanner
  trialEndsAt={subscription?.trial_ends_at}
/>
      <PremiumGate
        title="Executive Reporting Suite"
        description="Automated intelligence reports, operational analytics, scheduled executive summaries, and enterprise reporting controls require HarborGuard Professional."
      />
    </AppShell>
  );
}

return (
  <AppShell>
      <RoleGuard allowedRoles={["admin"]}>
        {message ? (
          <div
            style={{
              marginBottom: 20,
              padding: 14,
              borderRadius: 12,
              background: "#eff6ff",
              border: "1px solid #bfdbfe",
              color: "#1d4ed8",
            }}
          >
            {message}
          </div>
        ) : null}

        <div style={{ ...cardStyle, padding: 26, marginBottom: 24 }}>
          <h2 style={sectionTitleStyle}>Report Admin Dashboard</h2>
          <p style={{ ...mutedTextStyle, marginBottom: 18 }}>
            Trigger report runs manually, retry failures, manage subscriptions, and monitor delivery health.
          </p>

          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <button
              style={buttonStyle}
              onClick={() => runReports("daily")}
              disabled={runningDaily}
            >
              {runningDaily ? "Running Daily..." : "Run Daily Reports Now"}
            </button>

            <button
              style={secondaryButtonStyle}
              onClick={() => runReports("weekly")}
              disabled={runningWeekly}
            >
              {runningWeekly ? "Running Weekly..." : "Run Weekly Reports Now"}
            </button>

            <button
              style={secondaryButtonStyle}
              onClick={retryFailedReports}
              disabled={retryingFailed}
            >
              {retryingFailed ? "Retrying Failed..." : "Retry Failed Reports"}
            </button>

            <button
              style={dangerButtonStyle}
              onClick={clearOldFailedLogs}
              disabled={cleaningFailed}
            >
              {cleaningFailed ? "Cleaning..." : "Clear Old Failed Logs"}
            </button>

            <button
              style={secondaryButtonStyle}
              onClick={() => {
                loadLogs();
                loadSubscriptions();
              }}
            >
              Refresh Admin Data
            </button>
          </div>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
            gap: 20,
            marginBottom: 24,
          }}
        >
          {[
            { label: "Total Logs", value: summary.total },
            { label: "Success", value: summary.success },
            { label: "Failed", value: summary.failed },
            { label: "Success Rate", value: `${summary.successRate}%` },
          ].map((item, index) => (
            <div key={index} style={{ ...cardStyle, padding: 24 }}>
              <div style={{ color: "#64748b", fontSize: 14, marginBottom: 10 }}>
                {item.label}
              </div>
              <div style={{ fontSize: 34, fontWeight: 800, lineHeight: 1.1 }}>
                {item.value}
              </div>
            </div>
          ))}
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
            gap: 20,
            marginBottom: 24,
          }}
        >
          {[
            { label: "Last 24h Runs", value: summary.last24hLogs },
            { label: "Last 24h Success", value: summary.last24hSuccess },
            { label: "Last 24h Failed", value: summary.last24hFailed },
            { label: "Last Run", value: formatDateTime(summary.lastRunAt) },
          ].map((item, index) => (
            <div key={index} style={{ ...cardStyle, padding: 24 }}>
              <div style={{ color: "#64748b", fontSize: 14, marginBottom: 10 }}>
                {item.label}
              </div>
              <div
                style={{
                  fontSize: index === 3 ? 18 : 30,
                  fontWeight: 800,
                  lineHeight: 1.2,
                  wordBreak: "break-word",
                }}
              >
                {item.value}
              </div>
            </div>
          ))}
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: 24,
            marginBottom: 24,
          }}
        >
          <div style={{ ...cardStyle, padding: 26 }}>
            <h2 style={sectionTitleStyle}>Delivery Status Mix</h2>
            <p style={{ ...mutedTextStyle, marginBottom: 18 }}>
              Compare total successful and failed report deliveries.
            </p>

            <div
              style={{
                border: "1px solid #e5e7eb",
                borderRadius: 16,
                padding: 18,
                height: 340,
                background: "#fff",
              }}
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={statusChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="value" fill="#2563eb" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div style={{ ...cardStyle, padding: 26 }}>
            <h2 style={sectionTitleStyle}>7-Day Delivery Trend</h2>
            <p style={{ ...mutedTextStyle, marginBottom: 18 }}>
              Track success and failure volume over the last 7 days.
            </p>

            <div
              style={{
                border: "1px solid #e5e7eb",
                borderRadius: 16,
                padding: 18,
                height: 340,
                background: "#fff",
              }}
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={last7DaysTrend}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="label" />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="success" stroke="#16a34a" strokeWidth={3} />
                  <Line type="monotone" dataKey="failed" stroke="#dc2626" strokeWidth={3} />
                  <Line type="monotone" dataKey="total" stroke="#2563eb" strokeWidth={3} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: 24,
            marginBottom: 24,
          }}
        >
          <div style={{ ...cardStyle, padding: 26 }}>
            <h2 style={sectionTitleStyle}>Subscription Coverage</h2>
            <p style={{ ...mutedTextStyle, marginBottom: 18 }}>
              See enabled versus disabled subscriptions by frequency.
            </p>

            <div
              style={{
                border: "1px solid #e5e7eb",
                borderRadius: 16,
                padding: 18,
                height: 340,
                background: "#fff",
              }}
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={frequencyChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="enabled" fill="#16a34a" radius={[8, 8, 0, 0]} />
                  <Bar dataKey="disabled" fill="#dc2626" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div style={{ ...cardStyle, padding: 26 }}>
            <h2 style={sectionTitleStyle}>Top Failed Recipients Chart</h2>
            <p style={{ ...mutedTextStyle, marginBottom: 18 }}>
              Visualize recipients with the most failed report deliveries.
            </p>

            <div
              style={{
                border: "1px solid #e5e7eb",
                borderRadius: 16,
                padding: 18,
                height: 340,
                background: "#fff",
              }}
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={failedRecipientsChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="email" />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="count" fill="#dc2626" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div style={{ ...cardStyle, padding: 26, marginBottom: 24 }}>
          <h2 style={sectionTitleStyle}>Report Subscriptions</h2>
          <p style={{ ...mutedTextStyle, marginBottom: 18 }}>
            Enable or disable scheduled reports per user and frequency.
          </p>

          {loadingSubscriptions ? (
            <p style={mutedTextStyle}>Loading subscriptions...</p>
          ) : subscriptions.length === 0 ? (
            <p style={mutedTextStyle}>No subscriptions found.</p>
          ) : (
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", minWidth: 900 }}>
                <thead>
                  <tr>
                    {["Email", "Name", "Frequency", "Enabled", "Created", "Action"].map((h) => (
                      <th
                        key={h}
                        style={{
                          textAlign: "left",
                          padding: 14,
                          borderBottom: "1px solid #e5e7eb",
                          color: "#64748b",
                          fontSize: 13,
                          textTransform: "uppercase",
                          letterSpacing: "0.04em",
                        }}
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {subscriptions.map((sub) => (
                    <tr key={sub.id}>
                      <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9", fontWeight: 700 }}>
                        {sub.email}
                      </td>
                      <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9" }}>
                        {sub.full_name || "-"}
                      </td>
                      <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9", textTransform: "capitalize" }}>
                        {sub.report_frequency}
                      </td>
                      <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9" }}>
                        <span
                          style={{
                            color: sub.is_enabled ? "#16a34a" : "#dc2626",
                            fontWeight: 800,
                          }}
                        >
                          {sub.is_enabled ? "Enabled" : "Disabled"}
                        </span>
                      </td>
                      <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9" }}>
                        {formatShortDate(sub.created_at)}
                      </td>
                      <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9" }}>
                        <button
                          onClick={() => toggleSubscription(sub)}
                          disabled={togglingSubscriptionId === sub.id}
                          style={{
                            ...secondaryButtonStyle,
                            opacity: togglingSubscriptionId === sub.id ? 0.6 : 1,
                            cursor: togglingSubscriptionId === sub.id ? "not-allowed" : "pointer",
                          }}
                        >
                          {togglingSubscriptionId === sub.id
                            ? "Updating..."
                            : sub.is_enabled
                              ? "Disable"
                              : "Enable"}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1.2fr",
            gap: 24,
            marginBottom: 24,
          }}
        >
          <div style={{ ...cardStyle, padding: 26 }}>
            <h2 style={sectionTitleStyle}>Top Failed Recipients</h2>
            <p style={{ ...mutedTextStyle, marginBottom: 18 }}>
              Recipients with the most failed report deliveries.
            </p>

            {failedRecipients.length === 0 ? (
              <p style={mutedTextStyle}>No failed recipients found.</p>
            ) : (
              <div style={{ overflowX: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr>
                      {["Email", "Failure Count"].map((h) => (
                        <th
                          key={h}
                          style={{
                            textAlign: "left",
                            padding: 14,
                            borderBottom: "1px solid #e5e7eb",
                            color: "#64748b",
                            fontSize: 13,
                            textTransform: "uppercase",
                            letterSpacing: "0.04em",
                          }}
                        >
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {failedRecipients.map((item) => (
                      <tr key={item.email}>
                        <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9", fontWeight: 700 }}>
                          {item.email}
                        </td>
                        <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9", color: "#dc2626", fontWeight: 800 }}>
                          {item.count}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div style={{ ...cardStyle, padding: 26 }}>
            <h2 style={sectionTitleStyle}>Recent Failures</h2>
            <p style={{ ...mutedTextStyle, marginBottom: 18 }}>
              Latest failed report deliveries for investigation.
            </p>

            {recentFailures.length === 0 ? (
              <p style={mutedTextStyle}>No recent failures found.</p>
            ) : (
              <div style={{ display: "grid", gap: 12 }}>
                {recentFailures.map((log) => (
                  <div
                    key={log.id}
                    style={{
                      border: "1px solid #fecaca",
                      background: "#fef2f2",
                      borderRadius: 14,
                      padding: 14,
                    }}
                  >
                    <div style={{ fontWeight: 800, color: "#991b1b", marginBottom: 6 }}>
                      {log.email}
                    </div>
                    <div style={{ color: "#7f1d1d", fontSize: 14, marginBottom: 4 }}>
                      {log.report_frequency} â€¢ {log.start_date} â†’ {log.end_date}
                    </div>
                    <div style={{ color: "#7f1d1d", fontSize: 14, marginBottom: 4 }}>
                      {log.error_message || "Unknown failure"}
                    </div>
                    <div style={{ color: "#991b1b", fontSize: 12 }}>
                      {formatDateTime(log.created_at)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div style={{ ...cardStyle, padding: 26, marginBottom: 24 }}>
          <h2 style={sectionTitleStyle}>Recent Successes</h2>
          <p style={{ ...mutedTextStyle, marginBottom: 18 }}>
            Latest successful report deliveries.
          </p>

          {recentSuccesses.length === 0 ? (
            <p style={mutedTextStyle}>No recent successes found.</p>
          ) : (
            <div style={{ display: "grid", gap: 12 }}>
              {recentSuccesses.map((log) => (
                <div
                  key={log.id}
                  style={{
                    border: "1px solid #bbf7d0",
                    background: "#f0fdf4",
                    borderRadius: 14,
                    padding: 14,
                  }}
                >
                  <div style={{ fontWeight: 800, color: "#166534", marginBottom: 6 }}>
                    {log.email}
                  </div>
                  <div style={{ color: "#166534", fontSize: 14, marginBottom: 4 }}>
                    {log.report_frequency} â€¢ {log.start_date} â†’ {log.end_date}
                  </div>
                  <div style={{ color: "#166534", fontSize: 12 }}>
                    {formatDateTime(log.created_at)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div style={{ ...cardStyle, padding: 26 }}>
          <h2 style={sectionTitleStyle}>Latest Report Runs</h2>
          <p style={{ ...mutedTextStyle, marginBottom: 18 }}>
            Recent report delivery attempts across all recipients.
          </p>

          {loading ? (
            <p style={mutedTextStyle}>Loading report admin data...</p>
          ) : logs.length === 0 ? (
            <p style={mutedTextStyle}>No report activity found yet.</p>
          ) : (
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse", minWidth: 1200 }}>
                <thead>
                  <tr>
                    {[
                      "Recipient",
                      "Name",
                      "Frequency",
                      "Window",
                      "Status",
                      "Error",
                      "Created",
                    ].map((h) => (
                      <th
                        key={h}
                        style={{
                          textAlign: "left",
                          padding: 14,
                          borderBottom: "1px solid #e5e7eb",
                          color: "#64748b",
                          fontSize: 13,
                          textTransform: "uppercase",
                          letterSpacing: "0.04em",
                        }}
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {logs.map((log) => (
                    <tr key={log.id}>
                      <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9", fontWeight: 700 }}>
                        {log.email}
                      </td>
                      <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9" }}>
                        {log.full_name || "-"}
                      </td>
                      <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9", textTransform: "capitalize" }}>
                        {log.report_frequency}
                      </td>
                      <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9" }}>
                        {log.start_date} â†’ {log.end_date}
                      </td>
                      <td
                        style={{
                          padding: 14,
                          borderBottom: "1px solid #f1f5f9",
                          color: log.status === "success" ? "#16a34a" : "#dc2626",
                          fontWeight: 800,
                          textTransform: "capitalize",
                        }}
                      >
                        {log.status}
                      </td>
                      <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9", color: "#b91c1c" }}>
                        {log.error_message || "-"}
                      </td>
                      <td style={{ padding: 14, borderBottom: "1px solid #f1f5f9" }}>
                        {formatDateTime(log.created_at)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </RoleGuard>
    </AppShell>
  );
}
