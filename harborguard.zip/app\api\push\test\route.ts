import { NextResponse } from "next/server";

export async function POST() {
  if (process.env.NODE_ENV === "production") {
    return NextResponse.json(
      { error: "Not available in production." },
      { status: 404 }
    );
  }

  return NextResponse.json({
    success: true,
    notification: {
      title: "HarborGuard Alert",
      body: "Critical fleet anomaly detected.",
    },
  });
}
